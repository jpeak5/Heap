Written by Michael Taboada and Jason Peak.

To run, type java TestHeap <file> where <file> is an input file like karyHeapInput.txt
The heap is stored in Heap.java.

Output is in output.txt
